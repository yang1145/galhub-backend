class Review {
  constructor(id, userId, gameId, rating, comment) {
    this.id = id;
    this.userId = userId;
    this.gameId = gameId;
    this.rating = rating;
    this.comment = comment;
  }

  // 创建评论表
  static createTable(db) {
    const sql = `
      CREATE TABLE IF NOT EXISTS reviews (
        id SERIAL PRIMARY KEY,
        user_id INT NOT NULL,
        game_id INT NOT NULL,
        rating SMALLINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
        comment TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE,
        UNIQUE (user_id, game_id)
      )
    `;
    return db.execute(sql);
  }

  // 创建评论
  static async create(db, reviewData) {
    const { userId, gameId, rating, comment } = reviewData;
    const sql = `
      INSERT INTO reviews (user_id, game_id, rating, comment)
      VALUES ($1, $2, $3, $4)
      RETURNING id
    `;
    const [rows, result] = await db.execute(sql, [userId, gameId, rating, comment]);
    return [{ insertId: rows[0].id }, result];
  }

  // 根据游戏ID获取评论
  static findByGameId(db, gameId) {
    const sql = `
      SELECT r.*, u.username 
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      WHERE r.game_id = $1
      ORDER BY r.created_at DESC
    `;
    return db.execute(sql, [gameId]);
  }

  // 根据用户ID获取评论
  static findByUserId(db, userId) {
    const sql = `
      SELECT r.*, g.title as game_title
      FROM reviews r
      JOIN games g ON r.game_id = g.id
      WHERE r.user_id = $1
      ORDER BY r.created_at DESC
    `;
    return db.execute(sql, [userId]);
  }

  // 根据ID查找评论
  static findById(db, id) {
    const sql = `
      SELECT r.*, u.username, g.title as game_title
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      JOIN games g ON r.game_id = g.id
      WHERE r.id = $1
    `;
    return db.execute(sql, [id]);
  }

  // 更新评论
  static update(db, id, reviewData) {
    const { rating, comment } = reviewData;
    const sql = `
      UPDATE reviews
      SET rating = $1, comment = $2, updated_at = CURRENT_TIMESTAMP
      WHERE id = $3
    `;
    return db.execute(sql, [rating, comment, id]);
  }

  // 删除评论
  static delete(db, id) {
    const sql = 'DELETE FROM reviews WHERE id = $1';
    return db.execute(sql, [id]);
  }

  // 获取评论总数
  static async count(db) {
    const sql = 'SELECT COUNT(*) as total FROM reviews';
    const [rows] = await db.execute(sql);
    return parseInt(rows[0].total);
  }
}

module.exports = Review;